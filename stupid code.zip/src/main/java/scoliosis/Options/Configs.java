package scoliosis.Options;


public class Configs {

    @Property(type = Property.Type.BOOLEAN, name = "gangie what up", description = "i am become death destroyer of worlds")
    public static boolean main = false;
    @Property(type = Property.Type.BOOLEAN, name = "ahhh silly button", description = "")
    public static boolean sillybutton = false;
    @Property(type = Property.Type.BOOLEAN, name = "new phone who dis", description = "")
    public static boolean whodisbutton = false;
    @Property(type = Property.Type.BOOLEAN, name = "who dis new phone", description = "")
    public static boolean egg = false;
    @Property(type = Property.Type.BOOLEAN, name = "last button", description = "")
    public static boolean last = false;
}
