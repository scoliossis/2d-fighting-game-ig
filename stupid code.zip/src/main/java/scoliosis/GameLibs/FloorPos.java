package scoliosis.GameLibs;

public class FloorPos {
    public int x;
    public int y;

    public FloorPos(int x, int y) {
        this.x = x;
        this.y = y;
    }
}
